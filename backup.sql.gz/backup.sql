PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE transactions (
                id TEXT PRIMARY KEY,
                uid TEXT,
                planId TEXT,
                amount INTEGER,
                phone TEXT,
                mpesaCode TEXT,
                status TEXT,
                type TEXT,
                createdAt DATETIME,
                verifiedAt DATETIME,
                failureReason TEXT,
                verificationMetadata TEXT
            , campus_id TEXT, university_id TEXT);
CREATE TABLE users (
                uid TEXT PRIMARY KEY,
                email TEXT,
                credits INTEGER DEFAULT 0,
                unlimitedExpiresAt DATETIME,
                lastDailyReset DATETIME,
                lastPaymentRef TEXT
            );
INSERT INTO users VALUES('0AIC4EXGX1g3KI75UbR0gwgx7OM2','obieromakoth2007@gmail.com',2,NULL,'2026-01-29T11:15:48.438Z','CONSUME');
INSERT INTO users VALUES('0oyLC7U5hyZqbynspidGKn1GoJu1',NULL,2,NULL,'2026-02-01T18:38:22.699Z','CONSUME');
INSERT INTO users VALUES('675765587G87',NULL,0,NULL,'2026-01-20T15:52:23.818Z','txn_1768924342614');
INSERT INTO users VALUES('8NX8iMvGMydGiW1oyCQ6483Z7Jk1','saumunakuti109@gmail.com',2,NULL,'2026-01-28T13:31:26.456Z','CONSUME');
INSERT INTO users VALUES('8kQ4xArXgXVrwV9KRCx21x0sBTA3','galvanytech@gmail.com',42,NULL,'2026-01-19T21:46:22.749Z','CONSUME');
INSERT INTO users VALUES('9TlEmbmddEQ7hwVQQeo8xqW1vGl2',NULL,2,NULL,'2026-01-31T14:09:59.397Z','CONSUME');
INSERT INTO users VALUES('LRJ82HuK7BYUR3FVAvJ1eQhZTpn1','sph3234292025@students.uonbi.ac.ke',10,NULL,NULL,'CLOUD_IMPORT');
INSERT INTO users VALUES('MZOaHocQaqWFCCk0VPJLhC6S4tz2',NULL,0,NULL,'2026-02-02T00:42:31.449Z','CONSUME');
INSERT INTO users VALUES('MdPSyM6ZF1TuRoeHPnwyGq9FQLD3',NULL,1,NULL,'2026-01-31T15:46:27.649Z','CONSUME');
INSERT INTO users VALUES('OAxWwJdK1pagTvMnYj5BFPBymVD2','c300952025@students.uonbi.ac.ke',10,NULL,NULL,'CLOUD_IMPORT');
INSERT INTO users VALUES('QRqyqMgkGuXLEN24A0XboSwex4n2','goldashley333@gmail.com',10,NULL,NULL,'CLOUD_IMPORT');
INSERT INTO users VALUES('QrrDoqovGoXGwV4hiAamJQhLzYH3','kassimmusa322@gmail.com',6,NULL,'2026-01-30T18:16:20.476Z','TXN17697997371660KIIYY');
INSERT INTO users VALUES('SOz1lidrt4Zq0XBccoUinM2UL0l2','ampher.kilonzo25@students.dkut.ac.ke',10,NULL,NULL,'CLOUD_IMPORT');
INSERT INTO users VALUES('UPZaV6BuaCdIbOkzKhnB9AZZo1g2','brianigutu06@gmail.com',10,NULL,NULL,'CLOUD_IMPORT');
INSERT INTO users VALUES('XUqJIs0AsCSLA03xIg7gGt40SaV2','jasmine.wambui25@students.dkut.ac.ke',10,NULL,NULL,'CLOUD_IMPORT');
INSERT INTO users VALUES('eXVkqjh5Qub80oOLGqRYgEaplHz1','furahaemeriziana@gmail.com',2,NULL,'2026-01-30T21:21:31.501Z','CONSUME');
INSERT INTO users VALUES('ggpam2CRIyRuLiR3uhqP44Xbgi22','sph3234272025@students.uonbi.ac.ke',10,NULL,NULL,'CLOUD_IMPORT');
INSERT INTO users VALUES('iONtdt1NUgPYWjlhnb1gB6czZpD2','sarah.ngala25@students.dkut.ac.ke',1,NULL,'2026-01-30T18:13:24.538Z','CONSUME');
INSERT INTO users VALUES('jIlXZ6bYmaVYy48W6pQkzFPhkxy1','anyonageoffrey49@gmail.com',13,NULL,NULL,'yt3Y1jbDMTJ5J5ZgOA7R');
INSERT INTO users VALUES('lMZmYPslfrWQekqylbGJeMTDKcU2','brianogutu06@gmail.com',9,NULL,'2026-01-28T08:02:24.941Z','TXN1769588287345HTA83M');
INSERT INTO users VALUES('mNlJhXAFONgC1QugIZ6yZCuaqMr1',NULL,15,NULL,'2026-01-30T20:42:30.961Z','TXN1769806343715PSB3O5');
INSERT INTO users VALUES('ngrok_test_user',NULL,3,NULL,'2026-01-30T18:26:57.745Z','txn_1769797616093');
INSERT INTO users VALUES('test_backend_verify_user',NULL,4,NULL,'2026-01-19T21:37:35.257Z','CONSUME');
INSERT INTO users VALUES('test_user_verify_123',NULL,5,NULL,NULL,'CONSUME');
INSERT INTO users VALUES('v354aX44SMRKG9XdCpMa3e9UxJs1',NULL,106,NULL,'2026-01-19T21:47:36.559Z','TXN17690209032969TMBD1');
INSERT INTO users VALUES('w8aCztLrt6chRc0dROsAa7iffXy1','chrisantos.isoe25@students.dkut.ac.ke',2,NULL,'2026-01-28T14:05:48.695Z','CONSUME');
INSERT INTO users VALUES('xv2moVC6RiYaY0lEalb7g13Yf7Z2','mwebichris99@gmail.com',10,NULL,NULL,'CLOUD_IMPORT');
INSERT INTO users VALUES('yGmHOdGypQSplZFf8kdA2VyhDLE2','sph3233382025@students.uonbi.ac.ke',27,NULL,'2026-01-23T17:16:49.559Z','CONSUME');
CREATE TABLE sync_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                collection TEXT,
                docId TEXT,
                operation TEXT, -- 'create', 'update', 'delete'
                data TEXT, -- JSON string
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE universities (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                shortCode TEXT UNIQUE,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
            , structure_type TEXT DEFAULT 'campus', slug TEXT, colors TEXT, logoUrl TEXT, faviconUrl TEXT, ogImageUrl TEXT, tagline TEXT, defaultCampus TEXT);
INSERT INTO universities VALUES('uni_cuea','Catholic University of Eastern Africa','CUEA','2026-02-03T19:28:54.914Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO universities VALUES('uni_dkut','Dedan Kimathi University of Technology','DKUT','2026-02-03T19:28:54.919Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO universities VALUES('uni_jkuat','Jomo Kenyatta University of Agriculture and Technology','JKUAT','2026-02-03T19:28:54.924Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO universities VALUES('uni_ku','Kenyatta University','KU','2026-02-03T19:28:54.928Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO universities VALUES('uni_mmu','Maasai Mara University','MMU','2026-02-03T19:28:54.932Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO universities VALUES('uni_msu','Maseno University','MSU','2026-02-03T19:28:54.936Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO universities VALUES('uni_mu_1769790211184','Maseno University','MU','2026-02-03T19:28:54.940Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO universities VALUES('uni_tuk','Technical University of Kenya','tuk','2026-02-03T19:28:54.944Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO universities VALUES('uni_uon','University of Nairobi','UON','2026-02-03T19:28:54.947Z','campus',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
CREATE TABLE campuses (
                id TEXT PRIMARY KEY,
                universityId TEXT NOT NULL,
                name TEXT NOT NULL,
                slug TEXT UNIQUE,
                dataVersion INTEGER DEFAULT 1,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (universityId) REFERENCES universities(id)
            );
INSERT INTO campuses VALUES('camp_cuea_gaba','uni_cuea','Gaba Campus (Eldoret)','cuea_gaba',1,'2026-02-03T19:28:56.431Z');
INSERT INTO campuses VALUES('camp_cuea_main','uni_cuea','Main Campus (Langata)','cuea_main',1,'2026-02-03T19:28:56.436Z');
INSERT INTO campuses VALUES('campus_4iogc6lcu','uni_mu_1769790211184','Kisumu City Campus','mu_kisumu_city_campus',1,'2026-02-03T19:28:56.441Z');
INSERT INTO campuses VALUES('campus_dkut_business','uni_dkut','Business Mgt & Economics','dkut_business',1,'2026-02-03T19:28:56.525Z');
INSERT INTO campuses VALUES('campus_dkut_cs_it','uni_dkut','School of CS & IT','dkut_cs_it',1,'2026-02-03T19:28:56.530Z');
INSERT INTO campuses VALUES('campus_dkut_engineering','uni_dkut','School of Engineering','dkut_engineering',1,'2026-02-03T19:28:56.534Z');
INSERT INTO campuses VALUES('campus_dkut_institutes','uni_dkut','Institutes','dkut_institutes',1,'2026-02-03T19:28:56.540Z');
INSERT INTO campuses VALUES('campus_dkut_nursing','uni_dkut','School of Nursing','dkut_nursing',1,'2026-02-03T19:28:56.547Z');
INSERT INTO campuses VALUES('campus_dkut_science','uni_dkut','School of Science','dkut_science',1,'2026-02-03T19:28:56.555Z');
INSERT INTO campuses VALUES('campus_h8694549n','uni_mu_1769790211184','Odera Akang''o Campus','mu_odera_akang_o_campus',1,'2026-02-03T19:28:56.565Z');
INSERT INTO campuses VALUES('campus_jkuat_karen','uni_jkuat','Karen Campus','jkuat_karen',1,'2026-02-03T19:28:56.575Z');
INSERT INTO campuses VALUES('campus_jkuat_main','uni_jkuat','Main Campus','jkuat_main',1,'2026-02-03T19:28:56.625Z');
INSERT INTO campuses VALUES('campus_k5w5r1ssa','uni_mu_1769790211184','Main Campus','mu_main_campus',1,'2026-02-03T19:28:56.725Z');
INSERT INTO campuses VALUES('campus_kenya_science','uni_uon','Kenya Science Campus','kenya_science',1,'2026-02-03T19:28:56.736Z');
INSERT INTO campuses VALUES('campus_kikuyu','uni_uon','Kikuyu Campus','kikuyu',1,'2026-02-03T19:28:56.746Z');
INSERT INTO campuses VALUES('campus_knh','uni_uon','KNH Campus','knh',1,'2026-02-03T19:28:56.757Z');
INSERT INTO campuses VALUES('campus_ku_main','uni_ku','Main Campus','ku_main',1,'2026-02-03T19:28:56.773Z');
INSERT INTO campuses VALUES('campus_ku_parklands','uni_ku','Parklands Campus','ku_parklands',1,'2026-02-03T19:28:56.791Z');
INSERT INTO campuses VALUES('campus_ku_ruiru','uni_ku','Ruiru Campus','ku_ruiru',1,'2026-02-03T19:28:56.805Z');
INSERT INTO campuses VALUES('campus_l917q4sq1','uni_mu_1769790211184','eCampus','mu_ecampus',1,'2026-02-03T19:28:56.841Z');
INSERT INTO campuses VALUES('campus_lower_kabete','uni_uon','Lower Kabete Campus','lower_kabete',1,'2026-02-03T19:28:56.854Z');
INSERT INTO campuses VALUES('campus_main','uni_uon','Main Campus','main',1,'2026-02-03T19:28:56.874Z');
INSERT INTO campuses VALUES('campus_mmu_main','uni_mmu','Main Campus','mmu_main',1,'2026-02-03T19:28:56.926Z');
INSERT INTO campuses VALUES('campus_parklands','uni_uon','Parklands Campus','parklands',1,'2026-02-03T19:28:56.936Z');
INSERT INTO campuses VALUES('campus_upper_kabete','uni_uon','Upper Kabete Campus','upper_kabete',1,'2026-02-03T19:28:56.946Z');
INSERT INTO campuses VALUES('msu_OdAk','uni_msu','Odera Akang''o Campus','msu_OdAk',1,'2026-02-03T19:28:56.956Z');
INSERT INTO campuses VALUES('msu_eCamp','uni_msu','eCampus','msu_eCamp',1,'2026-02-03T19:28:56.965Z');
INSERT INTO campuses VALUES('msu_kisumu','uni_msu','Kisumu Campus','msu_kisumu',1,'2026-02-03T19:28:56.974Z');
INSERT INTO campuses VALUES('msu_main','uni_msu','Main Campus','msu_main',1,'2026-02-03T19:28:56.988Z');
INSERT INTO campuses VALUES('tuk_febe','uni_tuk','Faculty Of Engineering (FEBE)','tuk_febe',1,'2026-02-03T19:28:56.997Z');
CREATE TABLE faculties (
                id TEXT PRIMARY KEY,
                campusId TEXT NOT NULL,
                name TEXT NOT NULL,
                slug TEXT,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (campusId) REFERENCES campuses(id) ON DELETE CASCADE
            );
CREATE TABLE departments (
                id TEXT PRIMARY KEY,
                facultyId TEXT NOT NULL,
                name TEXT NOT NULL,
                slug TEXT,
                subLabel TEXT,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (facultyId) REFERENCES faculties(id) ON DELETE CASCADE
            );
CREATE TABLE options (
                id TEXT PRIMARY KEY,
                departmentId TEXT NOT NULL,
                name TEXT NOT NULL,
                slug TEXT,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (departmentId) REFERENCES departments(id) ON DELETE CASCADE
            );
CREATE TABLE timetables (
                id TEXT PRIMARY KEY,
                campusId TEXT NOT NULL,
                facultyId TEXT,
                departmentId TEXT,
                optionId TEXT,
                code TEXT NOT NULL,
                title TEXT,
                date TEXT NOT NULL,
                time TEXT NOT NULL,
                venue TEXT,
                level INTEGER,
                semester INTEGER,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                createdBy TEXT,
                FOREIGN KEY (campusId) REFERENCES campuses(id),
                FOREIGN KEY (facultyId) REFERENCES faculties(id),
                FOREIGN KEY (departmentId) REFERENCES departments(id),
                FOREIGN KEY (optionId) REFERENCES options(id)
            );
CREATE TABLE admins (
                uid TEXT PRIMARY KEY,
                email TEXT NOT NULL UNIQUE,
                role TEXT DEFAULT 'editor',
                scope TEXT NOT NULL,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                createdBy TEXT
            , custom_cut REAL DEFAULT NULL);
INSERT INTO admins VALUES('super_admin_init','kassimmusa322@gmail.com','super','*','2026-02-03 19:28:49','system',NULL);
CREATE TABLE messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fromUid TEXT NOT NULL,
                toUid TEXT,
                subject TEXT,
                body TEXT NOT NULL,
                isRead INTEGER DEFAULT 0,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                adminUid TEXT NOT NULL,
                adminEmail TEXT,
                action TEXT NOT NULL,
                entityType TEXT NOT NULL,
                entityId TEXT,
                changesSummary TEXT,
                affectedCount INTEGER,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE revenue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transactionId TEXT NOT NULL,
                campusId TEXT NOT NULL,
                amount INTEGER NOT NULL,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (campusId) REFERENCES campuses(id)
            );
CREATE TABLE admin_commissions (
                adminUid TEXT PRIMARY KEY,
                campusId TEXT NOT NULL,
                commissionRate REAL DEFAULT 0.10,
                totalEarned INTEGER DEFAULT 0,
                totalPaid INTEGER DEFAULT 0,
                lastCalculated DATETIME, universityId TEXT REFERENCES universities(id),
                FOREIGN KEY (campusId) REFERENCES campuses(id)
            );
CREATE TABLE commission_payouts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                adminUid TEXT NOT NULL,
                amount INTEGER NOT NULL,
                status TEXT DEFAULT 'pending',
                paidAt DATETIME,
                paidBy TEXT,
                paymentMethod TEXT,
                paymentRef TEXT,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE data_versions (
                campusId TEXT PRIMARY KEY,
                version INTEGER DEFAULT 1,
                lastUpdated DATETIME DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE visits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uid TEXT UNIQUE, -- Anonymous ID or User ID
                firstSeen DATETIME DEFAULT CURRENT_TIMESTAMP,
                lastSeen DATETIME DEFAULT CURRENT_TIMESTAMP,
                campusId TEXT,
                universityId TEXT
            );
INSERT INTO visits VALUES(1,'v_1770146896969_rjlk15gsy','2026-02-03T19:28:56.839Z','2026-02-03T19:28:56.839Z','jkuat_karen','uni_jkuat');
CREATE TABLE revenue_config (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                super_admin_cut REAL DEFAULT 60.0,
                admin_cut REAL DEFAULT 40.0,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_by TEXT
            );
INSERT INTO revenue_config VALUES(1,60.0,40.0,'2026-02-03 19:28:49',NULL);
CREATE TABLE ads (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                type TEXT NOT NULL CHECK (type IN ('image', 'gif', 'video', 'text')),
                mediaUrl TEXT,
                textContent TEXT,
                textStyle TEXT,
                hyperlink TEXT,
                duration INTEGER DEFAULT 10,
                priority INTEGER DEFAULT 0,
                scope TEXT DEFAULT 'global' CHECK (scope IN ('global', 'university')),
                universityId TEXT,
                status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'live', 'paused', 'ended')),
                enabled INTEGER DEFAULT 1,
                startDate DATETIME,
                endDate DATETIME,
                clicks INTEGER DEFAULT 0,
                impressions INTEGER DEFAULT 0,
                createdBy TEXT,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
            , position TEXT DEFAULT NULL, animation TEXT DEFAULT NULL, ctaPosition TEXT DEFAULT NULL);
CREATE TABLE ad_settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                adsEnabled INTEGER DEFAULT 0,
                emojiRainDuration INTEGER DEFAULT 30,
                adCycleDuration INTEGER DEFAULT 10,
                rotationMode TEXT DEFAULT 'sequential' CHECK (rotationMode IN ('sequential', 'random', 'priority')),
                defaultScope TEXT DEFAULT 'global',
                updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                updatedBy TEXT
            );
INSERT INTO ad_settings VALUES(1,0,30,10,'sequential','global','2026-02-03 19:28:49',NULL);
CREATE TABLE presets (
                id TEXT PRIMARY KEY,
                campusId TEXT NOT NULL,
                name TEXT NOT NULL,
                icon TEXT DEFAULT 'BookOpen',
                units TEXT NOT NULL,
                displayOrder INTEGER DEFAULT 0,
                enabled INTEGER DEFAULT 1,
                createdBy TEXT,
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
            );
CREATE TABLE user_presets (
                id TEXT PRIMARY KEY,
                userId TEXT NOT NULL,
                name TEXT NOT NULL,
                units TEXT NOT NULL, -- JSON string of CustomUnit objects
                contextId TEXT, -- Hierarchy scope (e.g. tuk_febe)
                createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
            );
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('visits',1);
INSERT INTO sqlite_sequence VALUES('sync_queue',1);
COMMIT;
